package csc372mod6;

import java.util.ArrayList;
import java.util.Comparator;

public class SelectionSort {
	public static void selectionSort(ArrayList<Student> list, Comparator<Student> comparator)	{
		int n = list.size();
		for(int i = 0; i < n - 1; i++)	{
			int minIdx = i;
			for(int j = i + 1; j < n; j++)	{
				if(comparator.compare(list.get(j), list.get(minIdx)) < 0)	{
					minIdx = j;
				}
			}
			
			Student temp = list.get(minIdx);
			list.set(minIdx, list.get(i));
			list.set(i, temp);
			
			System.out.println("After iteration " + (i + 1) + ":");
			for(Student s : list)	{
				System.out.println(s);
			}
			System.out.println();
		}
	}

}