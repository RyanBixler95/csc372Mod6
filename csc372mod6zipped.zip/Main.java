package csc372mod6;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
	public static void main(String[] args)	{
		Scanner scnr = new Scanner(System.in);
		ArrayList<Student> students = new ArrayList<>();
		
		System.out.println("Enter details for 10 students (rollno, name, address):");
		for(int i = 0; i < 10; i++)	{
			System.out.print("Roll number: ");
			int rollno = scnr.nextInt();
			scnr.nextLine();
			System.out.print("Name: ");
			String name = scnr.nextLine();
			System.out.print("Address: ");
			String address = scnr.nextLine();
			students.add(new Student(rollno, name, address));
		}
		
		System.out.println("Choose sorting criteria:");
		System.out.println("1. Name");
		System.out.println("2. Roll number");
		int choice = scnr.nextInt();
		
		Comparator<Student> comparator;
		if(choice == 1)	{
			comparator = new SortByName();
		} else	{
			comparator = new SortByRollno();
		}
		
		SelectionSort.selectionSort(students, comparator);
		
		System.out.println("\nSorted List:");
		for(Student s : students)	{
			System.out.println(s);
		}
		
		scnr.close();
	}
}